package com.bookService.service;

import java.util.List;

import com.bookService.entity.Book;


public interface BookService {

	
//	 public List<Book> getALlBooks() throws Exception;

	    public Book getMovieByRank(long rank) throws Exception;
	    
	    
	    
	    public Object getALlBooks() throws Exception;
	    
	    public Object getBooksBySeries(String series) throws Exception;
	    
	    
	    
}
