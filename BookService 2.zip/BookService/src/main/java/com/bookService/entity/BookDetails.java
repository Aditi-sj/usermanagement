package com.bookService.entity;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class BookDetails {

	private String title;
	
	private String title_search;
	
	private int page_count;
	
	
	private String series_name;
	
	
	private int  min_age;
	
	private int  max_age;
	
	private String book_type;
	
	
	private String language;
	
private List<String> authors;


private List<String> subcategories;

	
	private List<String> categories;
	
	
	
	
	private String summary;
	
	
//	
	
//	private String country_name;
	
	
	
	
	
	
	
	
	 
	
	
	
	
	
}
