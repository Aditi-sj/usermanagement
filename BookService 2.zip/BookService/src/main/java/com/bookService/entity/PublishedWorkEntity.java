package com.bookService.entity;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class PublishedWorkEntity {
	
	private long isbn;
	
	private boolean english_language_learner;
	
	private int copyright;
	
	private int  published_work_id;
	
	private int page_count;
	
	private String binding;
	
	private String cover_art_url;

}
